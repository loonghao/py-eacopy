"""Version information."""

__version__ = "0.0.1"
__eacopy_version__ = "0.0.1"
